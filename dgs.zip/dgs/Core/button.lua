dgsLogLuaMemory()
dgsRegisterType("dgs-dxbutton","dgsBasic","dgsType2D")
dgsRegisterProperties("dgs-dxbutton",{
	alignment = 			{	{ PArg.String, PArg.String }	},
	clickOffset = 			{	{ PArg.Number, PArg.Number }	},
	clickType = 			{	PArg.Number	},
	clip = 					{	PArg.Bool	},
	color =					{	{ PArg.Color, PArg.Color, PArg.Color }	},
	colorCoded = 			{	PArg.Bool	},
	colorTransitionPeriod = {	PArg.Number	},
	font = 					{	PArg.Font+PArg.String	},
	iconColor = 			{	PArg.Color, { PArg.Color, PArg.Color, PArg.Color }	},
	iconImage = 			{	PArg.Nil+PArg.Material, { PArg.Nil+PArg.Material, PArg.Nil+PArg.Material, PArg.Nil+PArg.Material }	},
	iconOffset = 			{	{ PArg.Number, PArg.Number }	},
	iconSize = 				{	{ PArg.Number, PArg.Number, PArg.String+PArg.Bool }	},
	image = 				{	PArg.Nil+PArg.Material, { PArg.Nil+PArg.Material, PArg.Nil+PArg.Material, PArg.Nil+PArg.Material }	},
	shadow = 				{	{ PArg.Number, PArg.Number, PArg.Color, PArg.Number+PArg.Bool+PArg.Nil, PArg.Font+PArg.Nil }, PArg.Nil	},
	subPixelPositioning = 	{	PArg.Bool	},
	text = 					{	PArg.Text	},
	textColor = 			{	PArg.Color	},
	textOffset = 			{	{ PArg.Number, PArg.Number, PArg.Bool }	},
	textSize = 				{	{ PArg.Number, PArg.Number }	},
	wordBreak = 			{	PArg.Bool	},
})

--Dx Functions
local dxDrawImage = dxDrawImage
local dxDrawImageSection = dxDrawImageSection
local dgsDrawText = dgsDrawText
local dxGetFontHeight = dxGetFontHeight
local dxGetTextWidth = dxGetTextWidth
--DGS Functions
local dgsSetType = dgsSetType
local dgsSetParent = dgsSetParent
local dgsGetType = dgsGetType
local dgsSetData = dgsSetData
local applyColorAlpha = applyColorAlpha
local dgsAttachToTranslation = dgsAttachToTranslation
local dgsAttachToAutoDestroy = dgsAttachToAutoDestroy
local calculateGuiPositionSize = calculateGuiPositionSize
local dgsCreateTextureFromStyle = dgsCreateTextureFromStyle
--Utilities
local triggerEvent = triggerEvent
local createElement = createElement
local assert = assert
local tonumber = tonumber
local type = type

function dgsCreateButton(...)
	local sRes = sourceResource or resource
	local x,y,w,h,text,relative,parent,textColor,scaleX,scaleY,normalImage,hoveringImage,clickedImage,normalColor,hoveringColor,clickedColor
	if select("#",...) == 1 and type(select(1,...)) == "table" then
		local argTable = ...
		x = argTable.x or argTable[1]
		y = argTable.y or argTable[2]
		w = argTable.width or argTable.w or argTable[3]
		h = argTable.height or argTable.h or argTable[4]
		text = argTable.text or argTable.txt or argTable[5]
		relative = argTable.relative or argTable.rlt or argTable[6]
		parent = argTable.parent or argTable.p or argTable[7]
		textColor = argTable.textColor or argTable[8]
		scaleX = argTable.scaleX or argTable[9]
		scaleY = argTable.scaleY or argTable[10]
		normalImage = argTable.normalImage or argTable[11]
		hoveringImage = argTable.hoveringImage or argTable[12]
		clickedImage = argTable.clickedImage or argTable[13]
		normalColor = argTable.normalColor or argTable[14]
		hoveringColor = argTable.hoveringColor or argTable[15]
		clickedColor = argTable.clickedColor or argTable[16]
	else
		x,y,w,h,text,relative,parent,textColor,scaleX,scaleY,normalImage,hoveringImage,clickedImage,normalColor,hoveringColor,clickedColor = ...
	end
	if not(type(x) == "number") then error(dgsGenAsrt(x,"dgsCreateButton",1,"number")) end
	if not(type(y) == "number") then error(dgsGenAsrt(y,"dgsCreateButton",2,"number")) end
	if not(type(w) == "number") then error(dgsGenAsrt(w,"dgsCreateButton",3,"number")) end
	if not(type(h) == "number") then error(dgsGenAsrt(h,"dgsCreateButton",4,"number")) end
	local button = createElement("dgs-dxbutton")
	dgsSetType(button,"dgs-dxbutton")
	
	local res = sRes ~= resource and sRes or "global"
	local style = styleManager.styles[res]
	local using = style.using
	style = style.loaded[using]
	local systemFont = style.systemFontElement
	style = style.button
	
	local normalColor = normalColor or style.color[1]
	local hoveringColor = hoveringColor or style.color[2]
	local clickedColor = clickedColor or style.color[3]
	local normalImage = normalImage or dgsCreateTextureFromStyle(using,res,style.image[1])
	local hoveringImage = hoveringImage or dgsCreateTextureFromStyle(using,res,style.image[2])
	local clickedImage = clickedImage or dgsCreateTextureFromStyle(using,res,style.image[3])
	local textSizeX,textSizeY = tonumber(scaleX) or style.textSize[1], tonumber(scaleY) or style.textSize[2]
	dgsElementData[button] = {
		alignment = {"center","center"},
		clickOffset = {0,0},
		clickType = 1;	--1:LMB;2:Wheel;3:RM,
		clip = nil,
		colorTransitionPeriod = 0, --ms
		color = {normalColor, hoveringColor, clickedColor},
		colorCoded = nil,
		font = style.font or systemFont,
		iconColor = 0xFFFFFFFF,
		iconDirection = "left",
		iconImage = nil,
		iconOffset = {0,0},
		iconSize = {1,1,"text"}; -- Can be false/true/"text"
		--iconShadow = {},
		imageTransformTime = 0, --ms
		image = {normalImage, hoveringImage, clickedImage},
		--shadow = {},
		textColor = tonumber(textColor) or style.textColor,
		textOffset = {0,0,false},
		textSize = {textSizeX, textSizeY},
		wordBreak = nil,
		renderBuffer = {
			lastState = 0,
		},
	}
	dgsSetParent(button,parent,true,true)
	dgsAttachToTranslation(button,resourceTranslation[sRes])
	if type(text) == "table" then
		dgsElementData[button]._translationText = text
		dgsSetData(button,"text",text)
	else
		dgsSetData(button,"text",tostring(text or ""))
	end
	calculateGuiPositionSize(button,x,y,relative or false,w,h,relative or false,true)
	triggerEvent("onDgsCreate",button,sRes)
	return button
end

--function dgsButtonSetIconImage()
--function dgsButtonSetIconColor()
----------------------------------------------------------------
--------------------------Renderer------------------------------
----------------------------------------------------------------
dgsRenderer["dgs-dxbutton"] = function(source,x,y,w,h,mx,my,cx,cy,enabledInherited,enabledSelf,eleData,parentAlpha,isPostGUI,rndtgt)
	local renderBuffer = eleData.renderBuffer
	local buttonState = 1
	if MouseData.entered == source then
		buttonState = 2
		if eleData.clickType == 1 then
			if MouseData.clickl == source then
				buttonState = 3
			end
		elseif eleData.clickType == 2 then
			if MouseData.clickr == source then
				buttonState = 3
			end
		else
			if MouseData.clickl == source or MouseData.clickr == source then
				buttonState = 3
			end
		end
	end
	if eleData.lastState ~= buttonState then
		eleData.lastState = eleData.currentState
		eleData.lastStateTick = getTickCount()
	end
	if eleData.currentState ~= buttonState then
		eleData.currentState = buttonState
		eleData.currentStateTick = getTickCount()
		renderBuffer.startColor = renderBuffer.currentColor or (type(eleData.color) ~= "table" and eleData.color or eleData.color[eleData.lastState])
	end
	local bgColor = type(eleData.color) ~= "table" and eleData.color or eleData.color[buttonState] 
	local bgImage = type(eleData.image) ~= "table" and eleData.image or eleData.image[buttonState]
	local finalcolor
	if not enabledInherited and not enabledSelf then
		if type(eleData.disabledColor) == "number" then
			finalcolor = applyColorAlpha(eleData.disabledColor,parentAlpha)
		elseif eleData.disabledColor == true then
			local r,g,b,a = fromcolor(bgColor,true)
			local average = (r+g+b)/3*eleData.disabledColorPercent
			finalcolor = tocolor(average,average,average,a*parentAlpha)
		else
			local targetColor = bgColor
			if eleData.colorTransitionPeriod > 0 then
				renderBuffer.currentColor = interpolateColor(renderBuffer.startColor or targetColor,targetColor,(getTickCount()-eleData.currentStateTick)/eleData.colorTransitionPeriod) -- todo
				finalcolor = applyColorAlpha(renderBuffer.currentColor,parentAlpha)
			else
				finalcolor = applyColorAlpha(targetColor,parentAlpha)
			end
		end
	else
		local targetColor = bgColor
		if eleData.colorTransitionPeriod > 0 and getTickCount()-eleData.currentStateTick <= eleData.colorTransitionPeriod then
			renderBuffer.currentColor = interpolateColor(renderBuffer.startColor or targetColor,targetColor,(getTickCount()-eleData.currentStateTick)/eleData.colorTransitionPeriod) -- todo
			finalcolor = applyColorAlpha(renderBuffer.currentColor,parentAlpha)
		else
			finalcolor = applyColorAlpha(targetColor,parentAlpha)
		end
	end
	------------------------------------
	if eleData.functionRunBefore then
		local fnc = eleData.functions
		if type(fnc) == "table" then
			fnc[1](unpack(fnc[2]))
		end
	end
	------------------------------------
	if finalcolor/0x1000000%256 >= 1 then	--Optimise when alpha = 0
		dxDrawImage(x,y,w,h,bgImage,0,0,0,finalcolor,isPostGUI,rndtgt)
	end
	local text = eleData.text
	local txtSizX,txtSizY = eleData.textSize[1],eleData.textSize[2] or eleData.textSize[1]
	
	local res = eleData.resource or "global"
	local style = styleManager.styles[res]
	local using = style.using
	style = style.loaded[style.using]
	local systemFont = style.systemFontElement
	
	local font = eleData.font or systemFont
	local colorCoded = eleData.colorCoded
	local textOffset = eleData.textOffset
	local txtoffsetsX = textOffset[3] and textOffset[1]*w or textOffset[1]
	local txtoffsetsY = textOffset[3] and textOffset[2]*h or textOffset[2]
	local alignment = eleData.alignment
	local iconImage = eleData.iconImage
	if iconImage then
		local iconColor = eleData.iconColor
		local iconShadow = eleData.iconShadow
		local iconSize = eleData.iconSize
		local fontHeight = dxGetFontHeight(txtSizY,font)
		local fontWidth = dxGetTextWidth(text,txtSizX,font,colorCoded)
		local iconHeight,iconWidth = iconSize[2],iconSize[1]
		if iconSize[3] == "text" then
			iconWidth,iconHeight = fontHeight*iconSize[1],fontHeight*iconSize[2]
		elseif iconSize[3] == true then
			iconWidth,iconHeight = w*iconSize[1],h*iconSize[2]
		end
		local posX,posY = txtoffsetsX,txtoffsetsY
		local iconOffset = eleData.iconOffset
		if type(iconOffset) == "table" then
			if eleData.iconDirection == "left" then
				if alignment[1] == "left" then
					posX = posX-iconWidth
				elseif alignment[1] == "right" then
					posX = posX+w-fontWidth-iconWidth
				else
					posX = posX+w/2-fontWidth/2-iconWidth
				end
			elseif eleData.iconDirection == "right" then
				if alignment[1] == "left" then
					posX = posX+fontWidth
				elseif alignment[1] == "right" then
					posX = posX+w
				else
					posX = posX+w/2+fontWidth/2
				end
			end
			if alignment[2] == "top" then
				posY = posY
			elseif alignment[2] == "bottom" then
				posY = posY+h-fontHeight
			else
				posY = posY+(h-iconHeight)/2
			end
			posX = posX+iconOffset[1]
			posY = posY+iconOffset[2]
		else
			if eleData.iconDirection == "left" then
				if alignment[1] == "left" then
					posX = posX-iconWidth-iconOffset
				elseif alignment[1] == "right" then
					posX = posX+w-fontWidth-iconWidth-iconOffset
				else
					posX = posX+w/2-fontWidth/2-iconWidth-iconOffset
				end
			elseif eleData.iconDirection == "right" then
				if alignment[1] == "left" then
					posX = posX+fontWidth+iconOffset
				elseif alignment[1] == "right" then
					posX = posX+w+iconOffset
				else
					posX = posX+w/2+fontWidth/2+iconOffset
				end
			end
			if alignment[2] == "top" then
				posY = posY-iconOffset
			elseif alignment[2] == "bottom" then
				posY = posY+h-fontHeight+iconOffset
			else
				posY = posY+(h-iconHeight)/2+iconOffset
			end
		end
		posX,posY = posX+x,posY+y
		iconImage = type(iconImage) ~= "table" and iconImage or iconImage[buttonState]
		iconColor = type(iconColor) ~= "table" and iconColor or iconColor[buttonState]
		if iconImage then
			if iconShadow then
				local shadowoffx,shadowoffy,shadowc,shadowIsOutline = iconShadow[1],iconShadow[2],iconShadow[3],iconShadow[4]
				if shadowoffx and shadowoffy and shadowc then
					local shadowc = applyColorAlpha(shadowc,parentAlpha)
					dxDrawImage(posX+shadowoffx,posY+shadowoffy,iconWidth,iconHeight,iconImage,0,0,0,shadowc,isPostGUI,rndtgt)
					if shadowIsOutline then
						dxDrawImage(posX-shadowoffx,posY+shadowoffy,iconWidth,iconHeight,iconImage,0,0,0,shadowc,isPostGUI,rndtgt)
						dxDrawImage(posX-shadowoffx,posY-shadowoffy,iconWidth,iconHeight,iconImage,0,0,0,shadowc,isPostGUI,rndtgt)
						dxDrawImage(posX+shadowoffx,posY-shadowoffy,iconWidth,iconHeight,iconImage,0,0,0,shadowc,isPostGUI,rndtgt)
					end
				end
			end
			dxDrawImage(posX,posY,iconWidth,iconHeight,iconImage,0,0,0,applyColorAlpha(iconColor,parentAlpha),isPostGUI,rndtgt)
		end
	end

	if #text ~= 0 then
		local clip = eleData.clip
		local wordBreak = eleData.wordBreak
		if buttonState == 3 then
			txtoffsetsX,txtoffsetsY = txtoffsetsX+eleData.clickOffset[1],txtoffsetsY+eleData.clickOffset[2]
		end
		local textX,textY = x+txtoffsetsX,y+txtoffsetsY
		local shadow = eleData.shadow
		local shadowOffsetX,shadowOffsetY,shadowColor,shadowIsOutline,shadowFont
		if shadow then
			shadowOffsetX,shadowOffsetY,shadowColor,shadowIsOutline,shadowFont = shadow[1],shadow[2],shadow[3],shadow[4],shadow[5]
			shadowColor = applyColorAlpha(shadowColor or white,parentAlpha)
		end
		
		local textColor = type(eleData.textColor) ~= "table" and eleData.textColor or (eleData.textColor[buttonState] or eleData.textColor[1])
		dgsDrawText(text,textX,textY,textX+w,textY+h,applyColorAlpha(textColor,parentAlpha),txtSizX,txtSizY,font,alignment[1],alignment[2],clip,wordBreak,isPostGUI,colorCoded,subPixelPos,0,0,0,0,shadowOffsetX,shadowOffsetY,shadowColor,shadowIsOutline,shadowFont)
	end

	return rndtgt,false,mx,my,0,0
end